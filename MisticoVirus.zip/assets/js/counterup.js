$(function(e) {
    $('.counter').countUp();
});