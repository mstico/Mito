$(function(e) {
    $('#example').DataTable();
} );