<?php
session_start();
include('./cfg/conexao.php');

if(empty($_POST['usuario']) || empty($_POST['senha'])) {
	header('Location: index.php');
	exit();
}

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);

$query = "select * from usuario where usuario = '{$usuario}' and senha = md5('{$senha}')";

$result = mysqli_query($conexao, $query);

$resultdias = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);





$percorrer = mysqli_fetch_array($result,MYSQLI_ASSOC);
$adm = $percorrer['adm'];
$tkn = $percorrer['tkn'];


if($row == 1 && $adm == 1 && $dias >= 1) {
	$_SESSION['usuario'] = $usuario;
	header('Location: ./painel/');
	exit();

} 

else if($adm == 3){
	$_SESSION['usuario'] = $usuario;
	header('Location: ./painel/');
	exit();
}

else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: index.php');
	exit();
}

