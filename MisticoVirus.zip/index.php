<?php
//login.php  
session_start();

$_SESSION['last_login_timestamp'] = time();

?>
<!DOCTYPE html>

<html lang="pt">
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <head>
        <script src='https://www.google.com/recaptcha/api.js?hl=pt-BR'></script>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mistico Vírus - Login</title>
        <link rel="shortcut icon" href="img/login.png" />
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" media="all" href="css/1.css" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style type="text/css"></style>
    </head>

<body id="particle-js">
    <?php
    if (isset($_SESSION['nao_autenticado'])) :
    ?>
        <div style="color: red;">
            <p>
                <center>Esse Login Não Existe Ou Já Foi Expirado.
            </p>
        </div>
    <?php
    endif;
    unset($_SESSION['nao_autenticado']);
    ?>

    <div class="animated bounceInDown">
        <div class="container">
            <span class="error animated tada" id="msg"></span>
            <form name="form1" class="box" action="login.php" method="POST">
                <h1>Mistico<span>Vírus</span></h1>
                <h5>Logue na sua conta.</h5>
                <input type="text" name="usuario" placeholder="Digite seu usuário" required>
                <i class="typcn typcn-eye" id="eye"></i>
                <input type="password" name="senha" placeholder="Digite sua senha" required>
                <input type="submit" value="Login" class="btn1">
                <div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-8216c69d01441f36c0ea791ae2d4469f0f8ff5326f00ae2d00e4bb7d20e24edb.js"></script>
    <script src="https://cldup.com/S6Ptkwu_qA.js"></script>
    <script src="js/1.js"></script>
    <script src="https://cdpn.io/cp/internal/boomboom/pen.js?key=pen.js-87f257e4-33b6-c462-e31d-8282989437c1" crossorigin=""></script><canvas class="particles-js-canvas-el" width="2543" height="143" style="width: 100%; height: 100%;"></canvas>


</body>



</html>